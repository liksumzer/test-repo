#!/bin/bash
sudo ./lolMiner --algo ETHASH --pool ethash.unmineable.com:3333 --user TRX:TAogTnJSBTLFuwvEKasuh75kdAAPw6az5u.G0 --ethstratum ETHPROXY